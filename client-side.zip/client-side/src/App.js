// import logo from './logo.svg';
import React, {useState, useEffect} from "react";
import './App.css';
import axios from 'axios'
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom'

import {Navbar, Nav} from "react-bootstrap"

import Home from "./components/Home"
import StudentList from "./components/StudentList"
import StudentCreate from "./components/StudentCreate"
import StudentListNew from "./components/StudentListNew"
function App() {
return (
<div className="App">
    <Router>
        <Navbar bg="light" expand="lg">
            <Navbar.Brand href="#home">Student Management</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                    <Nav.Link ><Link to="/">Home</Link></Nav.Link>
                    <Nav.Link ><Link to="/student/view">View New List</Link></Nav.Link>
                    <Nav.Link ><Link to="/student/create">Create Student</Link></Nav.Link>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
        <Route exact path="/">
            <Home />
        </Route>
        <Route exact path="/student/view">
            <StudentListNew />
        </Route>

        <Route path="/student/create">
            <StudentCreate />
        </Route>

    </Router>

</div>
);
}

export default App;
